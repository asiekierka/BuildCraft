@API(apiVersion="1.1",owner="BuildCraftAPI|core",provides="BuildCraftAPI|power")
package buildcraft.api.power;
import cpw.mods.fml.common.API;